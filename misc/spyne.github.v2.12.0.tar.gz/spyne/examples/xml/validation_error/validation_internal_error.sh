#!/bin/sh

xmllint --schema schema.xsd inst.xml

