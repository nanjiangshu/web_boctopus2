
.. _reference-protocol-dictdoc:

Dictionary Document
-------------------

.. automodule:: spyne.protocol.dictdoc
    :members:
    :show-inheritance:
