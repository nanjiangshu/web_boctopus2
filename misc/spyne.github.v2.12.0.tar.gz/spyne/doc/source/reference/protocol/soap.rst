
.. _reference-protocol-soap:

Soap 1.1
--------

.. automodule:: spyne.protocol.soap.soap11
    :members:
    :show-inheritance:
    :undoc-members:

