
.. _reference-server-twisted:

Http (Twisted)
--------------

.. automodule:: spyne.server.twisted.http
    :members:
    :inherited-members:
    :undoc-members:

.. automodule:: spyne.server.twisted.websocket
    :members:
    :inherited-members:
    :undoc-members:

